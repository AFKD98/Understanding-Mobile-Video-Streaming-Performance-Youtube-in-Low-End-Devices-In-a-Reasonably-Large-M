import numpy as np
import matplotlib.pyplot as plt 
import math
fff = '50'

changing = fff +'_brow_500_3sec.txt'
cpufile = 'cpu'+changing
ytdata = 'youtube66_chrome_150.txt'#+changing
memfile = 'mem'+changing
time_interval = 3
f = open(ytdata,mode = 'r', encoding = 'Latin-1')
x = f.read()

class pointcmt:
	def __init__(self,ts,cmts,fmts):
		self.ts=ts
		self.cmts=cmts
		self.fmts = fmts

ts = []
cmts = []
fmts = []
data_points_cmt=[]
cmt = x.split("&cmt=")
for j in range(1,len(cmt)):
	fmtsp = cmt[j-1].split("&")
	for k in range(len(fmtsp)):
		abcfm = fmtsp[k].split(',')[0].split("=")
		fmt = 0
		if abcfm[0] == 'fmt':
			fmt = abcfm[1]
			break
	nts = cmt[j].split("&")[0].split(",")
	for i in range(0,len(nts)):
			if len(nts[i]) > 20:
				break
			ab = nts[i].split(":")[0]

			abc = nts[i].split(":")[1]
			cmts.append(abc)
			ts.append(ab)
			fmts.append(fmt)
			data_points_cmt.append(pointcmt(float(ab),float(abc),float(fmt)))


data_points_cmt.sort(key=lambda x: x.ts)



cmts_values=[x.cmts for x in data_points_cmt]

ts_values=[x.ts for x in data_points_cmt]

fmts_values =[x.fmts for x in data_points_cmt]



###############################################

class pointbwm:
	def __init__(self,ts_bwms,bwms):
		self.ts_bwms=ts_bwms
		self.bwms=bwms

ts_bwms = []
bwms = []
data_points_bwms=[]
bwm = x.split("&bwm=")
for j in range(1,len(bwm)):

	nts = bwm[j].split("&")[0].split(",")
	for i in range(0,len(nts)):
			if len(nts[i]) > 30:
				break
			ab = nts[i].split(":")[0]

			abc = nts[i].split(":")[1]
			bwms.append(abc)
			ts_bwms.append(ab)
			data_points_bwms.append(pointbwm(float(ab),float(abc)))


data_points_bwms.sort(key=lambda x: x.ts_bwms)



bwms_values=[(x.bwms/10000) for x in data_points_bwms]

bwms_ts_values=[x.ts_bwms for x in data_points_bwms]




#####################################


class pointbh:
	def __init__(self,ts_bhs,bhs):
		self.ts_bhs=ts_bhs
		self.bhs=bhs

ts_bhs = []
bhs = []
data_points_bhs=[]
bh = x.split("&bh=")
for j in range(1,len(bh)):

	nts = bh[j].split("&")[0].split(",")
	for i in range(0,len(nts)):
			if len(nts[i]) > 20:
				break
			ab = nts[i].split(":")[0]

			abc = nts[i].split(":")[1]
			bhs.append(abc)
			ts_bhs.append(ab)
			data_points_bhs.append(pointbh(float(ab),float(abc)))


data_points_bhs.sort(key=lambda x: x.ts_bhs)



bhs_values=[x.bhs for x in data_points_bhs]

bhs_ts_values=[x.ts_bhs for x in data_points_bhs]

#############################################


class pointdf:
	def __init__(self,ts_dfs,dfs):
		self.ts_dfs=ts_dfs
		self.dfs=dfs

ts_dfs = []
dfs = []
data_points_dfs=[]
df = x.split("&df=")
for j in range(1,len(df)):

	nts = df[j].split("&")[0].split(",")
	for i in range(0,len(nts)):
			if len(nts[i]) > 20:
				break
			ab = nts[i].split(":")[0]

			abc = nts[i].split(":")[1]
			dfs.append(abc)
			ts_dfs.append(ab)
			data_points_dfs.append(pointdf(float(ab),float(abc)))


data_points_dfs.sort(key=lambda x: x.ts_dfs)



dfs_values=[x.dfs for x in data_points_dfs]

dfs_ts_values=[x.ts_dfs for x in data_points_dfs]

################################################
f = open(memfile,mode = 'r', encoding = 'Latin-1')
x = f.read()
mems = []
mem = x.split('TOTAL')
for j in range(1,len(mem)):
	me = mem[j].split(' ')[4]
	mems.append(me)

mems=  np.array(list(map(int, mems)))

mems = mems/1000
linear_time_mems = []
for k in range(0, time_interval*len(mems),time_interval):
	linear_time_mems.append((k))

###########################################
f.close()
f1 = open(cpufile,mode = 'r', encoding = 'Latin-1')
lines=f1.readlines()
CPU=[]
f1.close()
l=0
length=len(lines)
for x in lines:
    CPU.append(float(((x.split('%')[0]))[-2:]))
    if l==length-2:
    	break
    l=l+1
f1.close()
print('CPU')
print(CPU)
linear_time=[]
#adding smallest
ts=  list(map(float, ts))
bwms=  list(map(float, bwms))
diff1 = (max(ts_values) - len(CPU)*time_interval)
diff = (max(ts_values) - len(CPU)*time_interval)/len(CPU)
print('difference')
print(diff)
k = time_interval
# for k in range(0, int(max(ts_values)),time_interval+diff):
while k < max(ts_values):
	linear_time.append((k))
	k += time_interval
	if diff > 0:
		k += diff
	if len(linear_time) == len(CPU):
		break
print(len(linear_time))
print(len(CPU))
######################################################################
fig18=plt.figure(1)
N=150	
plt.gca().margins(x=0)
plt.gcf().canvas.draw()
tl = plt.gca().get_xticklabels()
maxsize = max([t.get_window_extent().width for t in tl])
m = 0.2 # inch margin
s = maxsize/plt.gcf().dpi*N+2*m
margin = m/plt.gcf().get_size_inches()[0]

plt.gcf().subplots_adjust(left=margin, right=1.-margin)
plt.gcf().set_size_inches(s, plt.gcf().get_size_inches()[1])
###############################################################################
CPU = np.divide(CPU,2)
mean=np.mean(CPU)
dfs_mean=np.mean(dfs_values)
print("CPU mean is:", mean)
print("dropped frame mean is:", dfs_mean)
CPU_mean=np.full(len(CPU),mean)


sumcpu1 = np.sum(CPU)
sumdf1 = np.sum(dfs_values)
stdcpu = np.std(CPU)


meanmem = np.mean(mems)
stdmem = np.std(mems)
meanmems = np.full(len(mems),meanmem)

meannbwm = np.mean(bwms_values)
stdbwm = np.std(bwms_values)

meanbwm = np.full(len(bwms_values),meannbwm)



for i in range(len(cmts_values)):
	if cmts_values[i] > 0.0:
		st_lt = ts_values[i]-cmts_values[i]
		break

rebuffering=ts_values[len(ts_values)-1]-cmts_values[len(cmts_values)-1] - st_lt

print("rebuffering in sec: ", rebuffering)
rebuffering_rate = (rebuffering/ts_values[len(ts_values)-1])*100


#########################################################


#########################################################
print(len(mems))
print(len(CPU))
print(max(ts_values))
print('fmts')
print(fmts_values)
print('cmts')
print(cmts_values)
print('ts_values')
print(ts_values)
print('buffer health')
print(bhs_values)
print('bwms')
print(bwms_values)
print('Dropped Frames')
print(dfs_values)

#####################################
print('\n\n')
print(ytdata)
print("SUM DF:",sumdf1)
print("mean bwm:",round(meannbwm,2))
print('std bwm:',round(stdbwm,2))



print("CPU mean is:", round(mean,2))
print("STD CPU:",round(stdcpu,2))
print("mean mem:",round(meanmem,2))
print('std mem:',round(stdmem,2))

print('\n\n')


#################

time_135 = 0
time_134 = 0
time_133 = 0
time_160 = 0

sortcmt = np.sort(cmts_values)
sortcmt = list(dict.fromkeys(sortcmt))
newfmt = []

for i in range(len(sortcmt)):
	newfmt.append(fmts_values[cmts_values.index(sortcmt[i])])

print(len(newfmt))
print(len(sortcmt))



for i in range(len(sortcmt)):

	if newfmt[i] == 18.0:
		time_135 = time_135 + sortcmt[i]
		if i>0:
			time_135 -= sortcmt[i-1]
	if newfmt[i] == 17.0:
		time_134 = time_134 + sortcmt[i]
		if i>0:
			time_134 -= sortcmt[i-1]
	if newfmt[i] == 16.0:
		time_133 = time_133 + sortcmt[i]
		if i>0:
			time_133 -= sortcmt[i-1]
	if newfmt[i] == 15.0:
		time_160 = time_160 + sortcmt[i]
		if i>0:
			time_160 -= sortcmt[i-1]

print('\n\n')
print(ytdata)
print('18: ',round(time_135*100/max(sortcmt),2))
print("mean bwm:",round(meannbwm,2))
print('std bwm:',round(stdbwm,2))

print('134: ',round(time_134*100/max(sortcmt),2))
print('133: ',round(time_133*100/max(sortcmt),2))
print('160: ',round(time_160*100/max(sortcmt),2))
print('\n\n')
###############
print('\n\n')
print(ytdata)
print("start-up latency in seconds: ", round(st_lt,2))
print("rebuffering in seconds: ", round(rebuffering,2))
print('\n\n')
###############

def setit(arr):
	arr2 = []
	arr2.append(arr[0])
	print(arr2)
	for i in range(1,len(arr)):
		if arr[i] - arr[i-1] > 1.5:
			arr2.append(arr[i])

	return arr2

adj_bh_ts = setit(bhs_ts_values)
adj_ts = setit(ts_values)



fontsze = 8
rot = 'vertical'
total_g = 3

# plt.subplot(total_g, 1, 1)
# plt.plot(ts_values, fmts_values, "-o")
# plt.title('Analysis')
# plt.ylabel('Format')
# plt.xticks(adj_ts, rotation= 'vertical',fontsize=8)

# plt.subplot(total_g, 1, 1)
# plt.plot(ts_values, cmts_values, "-o")
# plt.title('Analysis')
# plt.ylabel('Cmt(sec)')
# plt.xticks(adj_ts, rotation= 'vertical',fontsize=8)

plt.subplot(total_g, 1, 1)
plt.plot(bwms_ts_values, bwms_values, "-o")
plt.plot(bwms_ts_values, meanbwm, "-r")
plt.ylabel('bandwidth (kbps)')
plt.xticks(bwms_ts_values, rotation=rot,fontsize=fontsze)

plt.subplot(total_g, 1, 2)
plt.plot(linear_time, CPU, "-o")
plt.plot(linear_time, CPU_mean, "-r")
plt.ylabel('CPU Utilization (%)')
plt.xticks(adj_ts, rotation=rot,fontsize=fontsze)

plt.subplot(total_g, 1, 3)
plt.plot(ts_values, fmts_values, "-o")
plt.title("Bitrate")
plt.ylabel('Bitrate format')
plt.xlabel('Time (sec)')
plt.xticks(adj_bh_ts, rotation=rot,fontsize=fontsze)

# plt.subplot(total_g, 1, 3)
# plt.plot(linear_time_mems, mems, "-o")
# plt.plot(linear_time_mems, meanmems, "-r")
# plt.ylabel('Memory (MB)')
# plt.xlabel('Time Clock(sec)')
# plt.xticks(adj_bh_ts, rotation= rot,fontsize=fontsze)



# plt.subplot(total_g, 1, 1)
# plt.plot(linear_time_mems, mems, "-o")
# plt.ylabel('mem')
# plt.xticks(ts_values, rotation=rot,fontsize=fontsze)


# plt.subplot(total_g, 1, 2)
# plt.plot(bhs_ts_values, bhs_values, "-o")
# plt.ylabel('buffer health')
# plt.xticks(bhs_ts_values, rotation= 'vertical',fontsize=fontsze)

# plt.subplot(total_g, 1, 1)
# plt.plot(bwms_ts_values, bwms_values, "-o")
# plt.ylabel('bandwidth')
# plt.xticks(bwms_ts_values, rotation=rot,fontsize=fontsze)





# plt.subplot(4, 1, 3)
# plt.plot(ts_values, fmts_values, "-o")
# plt.ylabel('Bitrates')
# plt.xticks(ts_values, rotation= rot,fontsize=fontsze)

plt.subplots_adjust(hspace = 0.6)
# plt.show()
# plt.savefig("Bandwidth_bitrate.jpg")